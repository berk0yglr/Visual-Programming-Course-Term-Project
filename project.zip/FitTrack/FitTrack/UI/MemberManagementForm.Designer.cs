﻿namespace FitTrack.UI
{
    partial class MemberManagementForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFullName = new TextBox();
            txtPhone = new TextBox();
            txtEmail = new TextBox();
            cmbPackages = new ComboBox();
            btnSaveMember = new Button();
            dgvMembers = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            btnUpdateMember = new Button();
            btnDeleteMember = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvMembers).BeginInit();
            SuspendLayout();
            // 
            // txtFullName
            // 
            txtFullName.Location = new Point(320, 37);
            txtFullName.Name = "txtFullName";
            txtFullName.Size = new Size(100, 23);
            txtFullName.TabIndex = 0;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(320, 115);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(100, 23);
            txtPhone.TabIndex = 1;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(320, 76);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(100, 23);
            txtEmail.TabIndex = 2;
            // 
            // cmbPackages
            // 
            cmbPackages.FormattingEnabled = true;
            cmbPackages.Location = new Point(483, 40);
            cmbPackages.Name = "cmbPackages";
            cmbPackages.Size = new Size(121, 23);
            cmbPackages.TabIndex = 3;
            // 
            // btnSaveMember
            // 
            btnSaveMember.Location = new Point(320, 170);
            btnSaveMember.Name = "btnSaveMember";
            btnSaveMember.Size = new Size(116, 23);
            btnSaveMember.TabIndex = 4;
            btnSaveMember.Text = "Save Member";
            btnSaveMember.UseVisualStyleBackColor = true;
            btnSaveMember.Click += btnSaveMember_Click;
            // 
            // dgvMembers
            // 
            dgvMembers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMembers.Location = new Point(122, 265);
            dgvMembers.Name = "dgvMembers";
            dgvMembers.ReadOnly = true;
            dgvMembers.Size = new Size(544, 150);
            dgvMembers.TabIndex = 5;
            dgvMembers.CellClick += dgvMembers_CellClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(248, 40);
            label1.Name = "label1";
            label1.Size = new Size(64, 15);
            label1.TabIndex = 6;
            label1.Text = "Full Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(248, 79);
            label2.Name = "label2";
            label2.Size = new Size(44, 15);
            label2.TabIndex = 7;
            label2.Text = "Phone:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(248, 118);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 8;
            label3.Text = "Email:";
            // 
            // btnUpdateMember
            // 
            btnUpdateMember.Location = new Point(510, 110);
            btnUpdateMember.Name = "btnUpdateMember";
            btnUpdateMember.Size = new Size(75, 23);
            btnUpdateMember.TabIndex = 9;
            btnUpdateMember.Text = "Update Member";
            btnUpdateMember.UseVisualStyleBackColor = true;
            btnUpdateMember.Click += btnUpdateMember_Click;
            // 
            // btnDeleteMember
            // 
            btnDeleteMember.Location = new Point(510, 139);
            btnDeleteMember.Name = "btnDeleteMember";
            btnDeleteMember.Size = new Size(75, 23);
            btnDeleteMember.TabIndex = 10;
            btnDeleteMember.Text = "Delete Member";
            btnDeleteMember.UseVisualStyleBackColor = true;
            btnDeleteMember.Click += btnDeleteMember_Click;
            // 
            // MemberManagementForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDeleteMember);
            Controls.Add(btnUpdateMember);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dgvMembers);
            Controls.Add(btnSaveMember);
            Controls.Add(cmbPackages);
            Controls.Add(txtEmail);
            Controls.Add(txtPhone);
            Controls.Add(txtFullName);
            Name = "MemberManagementForm";
            Text = "MemberManagementForm";
            ((System.ComponentModel.ISupportInitialize)dgvMembers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFullName;
        private TextBox txtPhone;
        private TextBox txtEmail;
        private ComboBox cmbPackages;
        private Button btnSaveMember;
        private DataGridView dgvMembers;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button btnUpdateMember;
        private Button btnDeleteMember;
    }
}