﻿using System;
using System.Data;
using System.Linq; 
using System.Windows.Forms;
using FitTrack.DAL;

namespace FitTrack.UI
{
    public partial class MemberManagementForm : Form
    {
       
        private int selectedMemberId = 0;

        public MemberManagementForm()
        {
            InitializeComponent();
            dgvMembers.ReadOnly = true;
            dgvMembers.AllowUserToAddRows = false;
            dgvMembers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            LoadPackagesToCombo();
            LoadMembers();
        }

        private void LoadPackagesToCombo()
        {
            try
            {
                
                using (var context = new FitTrackContext())
                {
                    
                    var packages = context.Packages
                        .Select(p => new { p.Id, p.PackageName })
                        .ToList();

                    cmbPackages.DataSource = packages;
                    cmbPackages.DisplayMember = "PackageName";
                    cmbPackages.ValueMember = "Id";
                }
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

       
        private void btnSaveMember_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFullName.Text)) { MessageBox.Show("Please write a name !"); return; }

            try
            {
                int selectedPackageId = Convert.ToInt32(cmbPackages.SelectedValue);
                DateTime startDate = DateTime.Now;
                DateTime endDate = startDate.AddDays(30);

                using (var context = new FitTrackContext())
                {
                    
                    var newMember = new Member
                    {
                        FullName = txtFullName.Text,
                        Phone = txtPhone.Text,
                        Email = txtEmail.Text,
                        PackageId = selectedPackageId,
                        StartDate = startDate,
                        EndDate = endDate,
                        IsActive = true
                    };

                    context.Members.Add(newMember);
                    context.SaveChanges(); 
                }

                MessageBox.Show("Member added!");
                Temizle();
                LoadMembers();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

        
        private void btnUpdateMember_Click(object sender, EventArgs e)
        {
            if (selectedMemberId == 0) { MessageBox.Show("Please first choose a member from the table"); return; }

            try
            {
                using (var context = new FitTrackContext())
                {
                    
                    var memberToUpdate = context.Members.Find(selectedMemberId);

                    if (memberToUpdate != null)
                    {
                        memberToUpdate.FullName = txtFullName.Text;
                        memberToUpdate.Phone = txtPhone.Text;
                        memberToUpdate.Email = txtEmail.Text;
                        memberToUpdate.PackageId = Convert.ToInt32(cmbPackages.SelectedValue);

                        context.SaveChanges(); 
                    }
                }
                MessageBox.Show("Member uptated!");
                Temizle();
                LoadMembers();
            }
            catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
        }

  
        private void btnDeleteMember_Click(object sender, EventArgs e)
        {
            if (selectedMemberId == 0) { MessageBox.Show("Please first select the member to be deleted from the table!"); return; }

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete the member?", "Are you sure?", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    using (var context = new FitTrackContext())
                    {
                        
                        var memberToDelete = context.Members.Find(selectedMemberId);
                        if (memberToDelete != null)
                        {
                            context.Members.Remove(memberToDelete);
                            context.SaveChanges();
                        }
                    }
                    MessageBox.Show("Member deleted!");
                    Temizle();
                    LoadMembers();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

       
        private void dgvMembers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvMembers.Rows[e.RowIndex];

                selectedMemberId = Convert.ToInt32(row.Cells["Id"].Value);
                txtFullName.Text = row.Cells["FullName"].Value?.ToString();
                txtPhone.Text = row.Cells["Phone"].Value?.ToString();
                txtEmail.Text = row.Cells["Email"].Value?.ToString();
                cmbPackages.Text = row.Cells["PackageName"].Value?.ToString();
            }
        }

        private void LoadMembers()
        {
            try
            {
                using (var context = new FitTrackContext())
                {
                    
                    var memberList = context.Members
                        .Join(context.Packages,
                              m => m.PackageId,
                              p => p.Id,
                              (m, p) => new
                              {
                                  m.Id,
                                  m.FullName,
                                  m.Phone,
                                  m.Email,
                                  p.PackageName,
                                  m.StartDate,
                                  m.EndDate
                              })
                        .ToList(); 

                    dgvMembers.DataSource = memberList;

                    if (dgvMembers.Columns["Id"] != null)
                    {
                        dgvMembers.Columns["Id"].Visible = false;
                    }
                }
            }
            catch (Exception ex) { MessageBox.Show("The list could not be loaded: " + ex.Message); }
        }

        private void Temizle()
        {
            txtFullName.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
            selectedMemberId = 0;
        }
    }
}