﻿namespace FitTrack
{
    partial class DashboardForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            button1 = new Button();
            button2 = new Button();
            dgvExpiringMembers = new DataGridView();
            lblTotalMembers = new Label();
            lblTotalPackages = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvExpiringMembers).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(321, 79);
            label1.Name = "label1";
            label1.Size = new Size(112, 15);
            label1.TabIndex = 0;
            label1.Text = "FitTrack Main Menu";
            // 
            // button1
            // 
            button1.Location = new Point(412, 153);
            button1.Name = "button1";
            button1.Size = new Size(143, 23);
            button1.TabIndex = 2;
            button1.Text = "Member Management";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(222, 153);
            button2.Name = "button2";
            button2.Size = new Size(127, 23);
            button2.TabIndex = 3;
            button2.Text = "Manage Packages";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // dgvExpiringMembers
            // 
            dgvExpiringMembers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvExpiringMembers.Location = new Point(222, 219);
            dgvExpiringMembers.Name = "dgvExpiringMembers";
            dgvExpiringMembers.Size = new Size(333, 150);
            dgvExpiringMembers.TabIndex = 4;
            dgvExpiringMembers.CellContentClick += dgvExpiringMembers_CellContentClick;
            // 
            // lblTotalMembers
            // 
            lblTotalMembers.AutoSize = true;
            lblTotalMembers.Location = new Point(195, 79);
            lblTotalMembers.Name = "lblTotalMembers";
            lblTotalMembers.Size = new Size(82, 15);
            lblTotalMembers.TabIndex = 5;
            lblTotalMembers.Text = "Toplam Üye: 0";
            lblTotalMembers.Click += label2_Click;
            // 
            // lblTotalPackages
            // 
            lblTotalPackages.AutoSize = true;
            lblTotalPackages.Location = new Point(481, 79);
            lblTotalPackages.Name = "lblTotalPackages";
            lblTotalPackages.Size = new Size(91, 15);
            lblTotalPackages.TabIndex = 6;
            lblTotalPackages.Text = "Toplam Paket: 0";
            // 
            // DashboardForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblTotalPackages);
            Controls.Add(lblTotalMembers);
            Controls.Add(dgvExpiringMembers);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label1);
            Name = "DashboardForm";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)dgvExpiringMembers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private Button button2;
        private DataGridView dgvExpiringMembers;
        private Label lblTotalMembers;
        private Label lblTotalPackages;
    }
}
