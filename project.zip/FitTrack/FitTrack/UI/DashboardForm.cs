using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using FitTrack.DAL;
using FitTrack.UI;

namespace FitTrack
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
            LoadStatistics();
        }

        private void LoadStatistics()
        {
            try
            {
                using (var context = new FitTrackContext())
                {
                    int totalMembers = context.Members.Count();
                    lblTotalMembers.Text = "Total Members : " + totalMembers.ToString();

                    int totalPackages = context.Packages.Count();
                    lblTotalPackages.Text = "Total Packages: " + totalPackages.ToString();

                    DateTime thresholdDate = DateTime.Now.AddDays(35);

                    var expiringMembers = context.Members
                        .Where(m => m.EndDate <= thresholdDate)
                        .Select(m => new
                        {
                            Name = m.FullName,
                            Number = m.Phone,
                            EndDate = m.EndDate
                        })
                        .ToList();

                    dgvExpiringMembers.DataSource = expiringMembers;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load statistics: " + ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MemberManagementForm memberForm = new MemberManagementForm();
            memberForm.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PackageDefinitionForm packageForm = new PackageDefinitionForm();
            packageForm.ShowDialog();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            PackageDefinitionForm packageForm = new PackageDefinitionForm();
            packageForm.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e) { }
        private void dgvExpiringMembers_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
    }
}