﻿using System;
using System.Linq;
using System.Windows.Forms;
using FitTrack.DAL;

namespace FitTrack.UI
{
    public partial class PackageDefinitionForm : Form
    {
        private int selectedPackageId = 0;

        public PackageDefinitionForm()
        {
            InitializeComponent();

            dgvPackages.ReadOnly = true;
            dgvPackages.AllowUserToAddRows = false;
            dgvPackages.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            LoadPackages();
        }

        private void btnSavePackage_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtPackageName.Text) ||
                string.IsNullOrWhiteSpace(txtDuration.Text) ||
                string.IsNullOrWhiteSpace(txtPrice.Text))
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            try
            {
                using (var context = new FitTrackContext())
                {
                    var newPackage = new Package
                    {
                        PackageName = txtPackageName.Text,
                        DurationInDays = Convert.ToInt32(txtDuration.Text),
                        Price = Convert.ToDecimal(txtPrice.Text)
                    };

                    context.Packages.Add(newPackage);
                    context.SaveChanges();
                }

                MessageBox.Show("Package saved successfully!");

                txtPackageName.Clear();
                txtDuration.Clear();
                txtPrice.Clear();
                LoadPackages();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnDeletePackage_Click(object sender, EventArgs e)
        {
            if (selectedPackageId == 0) { MessageBox.Show("Please select a package from the table first!"); return; }

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this package?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                try
                {
                    using (var context = new FitTrackContext())
                    {
                        var packageToDelete = context.Packages.Find(selectedPackageId);

                        if (packageToDelete != null)
                        {
                            context.Packages.Remove(packageToDelete);
                            context.SaveChanges();
                        }
                    }
                    MessageBox.Show("Deleted!");
                    selectedPackageId = 0;
                    LoadPackages();
                }
                catch (Exception ex) { MessageBox.Show("Error: " + ex.Message); }
            }
        }

        private void dgvPackages_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvPackages.Rows[e.RowIndex];
                selectedPackageId = Convert.ToInt32(row.Cells["Id"].Value);
            }
        }

        private void LoadPackages()
        {
            try
            {
                using (var context = new FitTrackContext())
                {
                    dgvPackages.DataSource = context.Packages.ToList();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading list: " + ex.Message);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
        }
    }
}