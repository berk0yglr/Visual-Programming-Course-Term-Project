﻿namespace FitTrack.UI
{
    partial class PackageDefinitionForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtPackageName = new TextBox();
            txtDuration = new TextBox();
            label2 = new Label();
            label3 = new Label();
            txtPrice = new TextBox();
            btnSavePackage = new Button();
            dgvPackages = new DataGridView();
            button1 = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvPackages).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(221, 69);
            label1.Name = "label1";
            label1.Size = new Size(86, 15);
            label1.TabIndex = 0;
            label1.Text = "Package Name";
            // 
            // txtPackageName
            // 
            txtPackageName.Location = new Point(367, 66);
            txtPackageName.Name = "txtPackageName";
            txtPackageName.Size = new Size(100, 23);
            txtPackageName.TabIndex = 1;
            // 
            // txtDuration
            // 
            txtDuration.Location = new Point(367, 111);
            txtDuration.Name = "txtDuration";
            txtDuration.Size = new Size(100, 23);
            txtDuration.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(221, 119);
            label2.Name = "label2";
            label2.Size = new Size(89, 15);
            label2.TabIndex = 3;
            label2.Text = "Duration (Days)";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(221, 169);
            label3.Name = "label3";
            label3.Size = new Size(50, 15);
            label3.TabIndex = 4;
            label3.Text = "Price ($)";
            label3.Click += label3_Click;
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(367, 161);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(100, 23);
            txtPrice.TabIndex = 5;
            // 
            // btnSavePackage
            // 
            btnSavePackage.Location = new Point(328, 215);
            btnSavePackage.Name = "btnSavePackage";
            btnSavePackage.Size = new Size(104, 23);
            btnSavePackage.TabIndex = 6;
            btnSavePackage.Text = "Save Package";
            btnSavePackage.UseVisualStyleBackColor = true;
            btnSavePackage.Click += btnSavePackage_Click;
            // 
            // dgvPackages
            // 
            dgvPackages.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPackages.Location = new Point(180, 261);
            dgvPackages.Name = "dgvPackages";
            dgvPackages.ReadOnly = true;
            dgvPackages.Size = new Size(415, 150);
            dgvPackages.TabIndex = 7;
            dgvPackages.CellClick += dgvPackages_CellClick;
            // 
            // button1
            // 
            button1.Location = new Point(557, 133);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 8;
            button1.Text = "Delete";
            button1.UseVisualStyleBackColor = true;
            button1.Click += btnDeletePackage_Click;
            // 
            // PackageDefinitionForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(dgvPackages);
            Controls.Add(btnSavePackage);
            Controls.Add(txtPrice);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtDuration);
            Controls.Add(txtPackageName);
            Controls.Add(label1);
            Name = "PackageDefinitionForm";
            Text = "PackageDefinitionForm";
            ((System.ComponentModel.ISupportInitialize)dgvPackages).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtPackageName;
        private TextBox txtDuration;
        private Label label2;
        private Label label3;
        private TextBox txtPrice;
        private Button btnSavePackage;
        private DataGridView dgvPackages;
        private Button button1;
    }
}