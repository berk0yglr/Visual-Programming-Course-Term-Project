﻿using System;

namespace FitTrack.DAL
{
    public class Package
    {
        public int Id { get; set; }
        public string PackageName { get; set; } = string.Empty; 
        public int DurationInDays { get; set; }
        public decimal Price { get; set; }
    }
}