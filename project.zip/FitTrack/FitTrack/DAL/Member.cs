﻿using System;

namespace FitTrack.DAL
{
    public class Member
    {
        public int Id { get; set; }
        public string FullName { get; set; } = string.Empty; 
        public string Phone { get; set; } = string.Empty;    
        public string Email { get; set; } = string.Empty;    
        public int PackageId { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsActive { get; set; }
    }
}