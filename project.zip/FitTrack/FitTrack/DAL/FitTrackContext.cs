﻿using Microsoft.EntityFrameworkCore;

namespace FitTrack.DAL
{
    public class FitTrackContext : DbContext
    {
        public DbSet<Package> Packages { get; set; }
        public DbSet<Member> Members { get; set; }

        public FitTrackContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source=FitTrackDB.sqlite");
        }
    }
}