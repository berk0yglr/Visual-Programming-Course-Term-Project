using System;
using System.Windows.Forms;
using FitTrack.DAL;
using FitTrack.UI;

namespace FitTrack
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();

            
            using (var context = new FitTrackContext())
            {
                context.Database.EnsureCreated();
            }

            Application.Run(new DashboardForm());
        }
    }
}