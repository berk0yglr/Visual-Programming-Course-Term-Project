﻿using System;

namespace FitTrack.BLL
{
    public class MembershipManager
    {
        public DateTime CalculateExpirationDate(DateTime startDate, int durationInDays)
        {
            return startDate.AddDays(durationInDays);
        }

        public string CheckMembershipStatus(DateTime expirationDate)
        {
            if (expirationDate > DateTime.Now)
            {
                return "Active";
            }
            return "Inactive";
        }
    }
}